function getLog(){
    var logMessage = searchCookie(kay);
}